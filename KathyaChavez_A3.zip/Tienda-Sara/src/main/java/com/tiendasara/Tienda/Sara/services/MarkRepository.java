package com.tiendasara.Tienda.Sara.services;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tiendasara.Tienda.Sara.models.Mark;

public interface MarkRepository extends JpaRepository<Mark, Integer>{
    
}

